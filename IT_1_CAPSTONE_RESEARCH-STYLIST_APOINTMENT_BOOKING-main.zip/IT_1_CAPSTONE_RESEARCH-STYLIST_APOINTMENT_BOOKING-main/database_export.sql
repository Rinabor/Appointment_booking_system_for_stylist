-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mariadb
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Appointment`
--

DROP TABLE IF EXISTS `Appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Appointment` (
  `AppointmentID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AppointmentDate` date NOT NULL,
  `StartTime` time DEFAULT NULL,
  `EndTime` time DEFAULT NULL,
  `Status` varchar(20) NOT NULL,
  `CustomerID` int(10) unsigned NOT NULL,
  `StylistID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`AppointmentID`),
  KEY `Customer_Appointment` (`CustomerID`),
  KEY `Stylist_Appointment` (`StylistID`),
  CONSTRAINT `Customer_Appointment` FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`),
  CONSTRAINT `Stylist_Appointment` FOREIGN KEY (`StylistID`) REFERENCES `Stylist` (`StylistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Appointment`
--

LOCK TABLES `Appointment` WRITE;
/*!40000 ALTER TABLE `Appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AppointmentNotification`
--

DROP TABLE IF EXISTS `AppointmentNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AppointmentNotification` (
  `NotificationID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NotificationType` varchar(40) NOT NULL,
  `SentTime` datetime NOT NULL,
  `AppointmentID` int(10) unsigned NOT NULL,
  `CustomerID` int(10) unsigned NOT NULL,
  `NotificationMessage` text DEFAULT NULL,
  `StylistID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`NotificationID`),
  KEY `Appointment_AppointmentNotification` (`AppointmentID`),
  KEY `Customer_AppointmentNotification` (`CustomerID`),
  KEY `Stylist_AppointmentNotification` (`StylistID`),
  CONSTRAINT `Appointment_AppointmentNotification` FOREIGN KEY (`AppointmentID`) REFERENCES `Appointment` (`AppointmentID`),
  CONSTRAINT `Customer_AppointmentNotification` FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`),
  CONSTRAINT `Stylist_AppointmentNotification` FOREIGN KEY (`StylistID`) REFERENCES `Stylist` (`StylistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AppointmentNotification`
--

LOCK TABLES `AppointmentNotification` WRITE;
/*!40000 ALTER TABLE `AppointmentNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `AppointmentNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `CustomerID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `ContactNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` text DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CustomerPreferences`
--

DROP TABLE IF EXISTS `CustomerPreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CustomerPreferences` (
  `PreferenceID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ServiceType` text NOT NULL,
  `PreferredDate` date DEFAULT NULL,
  `PreferredTime` time DEFAULT NULL,
  `CustomerID` int(10) unsigned NOT NULL,
  `StylistID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`PreferenceID`),
  KEY `Customer_CustomerPreferences` (`CustomerID`),
  KEY `Stylist_CustomerPreferences` (`StylistID`),
  CONSTRAINT `Customer_CustomerPreferences` FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`),
  CONSTRAINT `Stylist_CustomerPreferences` FOREIGN KEY (`StylistID`) REFERENCES `Stylist` (`StylistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CustomerPreferences`
--

LOCK TABLES `CustomerPreferences` WRITE;
/*!40000 ALTER TABLE `CustomerPreferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `CustomerPreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Stylist`
--

DROP TABLE IF EXISTS `Stylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Stylist` (
  `StylistID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) NOT NULL,
  `Lastname` varchar(40) NOT NULL,
  `Specialization` varchar(100) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `ExperienceYears` tinyint(3) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`StylistID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stylist`
--

LOCK TABLES `Stylist` WRITE;
/*!40000 ALTER TABLE `Stylist` DISABLE KEYS */;
INSERT INTO `Stylist` VALUES (1,'animal','animal','Barber','123131','animal@gmail.com',1,'$2y$10$r7xMYI6SQL8AR5rMqepSZOea0Up1hBxtkx6O0fa7uEp7S7wicQ44K');
/*!40000 ALTER TABLE `Stylist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StylistSchedule`
--

DROP TABLE IF EXISTS `StylistSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StylistSchedule` (
  `ScheduleID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DayOfWeek` varchar(100) NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `StylistID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ScheduleID`),
  KEY `Stylist_StylistSchedule` (`StylistID`),
  CONSTRAINT `Stylist_StylistSchedule` FOREIGN KEY (`StylistID`) REFERENCES `Stylist` (`StylistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StylistSchedule`
--

LOCK TABLES `StylistSchedule` WRITE;
/*!40000 ALTER TABLE `StylistSchedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `StylistSchedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-24  8:53:11
